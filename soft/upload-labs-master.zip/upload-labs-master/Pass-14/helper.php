<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass使用getimagesize()检查是否为图片文件！';
}
?>