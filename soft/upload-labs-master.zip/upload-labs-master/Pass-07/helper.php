<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass禁止上传所有可以解析的后缀！';
}
?>