from django.shortcuts import render,HttpResponse
from dwebsocket.decorators import accept_websocket
import psutil,time,json
from MyWeb import models


@accept_websocket
def main(request):
    if not request.is_websocket():
        User_Count = len(psutil.users())
        User_Proc = len(psutil.pids())
        return render(request, "main.html", {"User_Count": User_Count, "User_Proc": User_Proc})
    else:
        while True:
            times = time.strftime("%M:%S", time.localtime())
            data = psutil.cpu_percent(interval=None, percpu=True)
            mem = psutil.virtual_memory()
            mem_used = int(mem.used / 1024 / 1024)
            print(mem_used)
            js = {"time":times,"load":data,"mem_used":mem_used}
            sen = json.dumps(js)
            request.websocket.send(sen)
            time.sleep(1)


# 主机列表获取接口
def get_host(request):
    ret = []
    obj = models.HostDB.objects.all()
    for item in range(0,len(obj)):
        ret.append(obj.values()[item])
    data = {
        "code":0,
        "msg":"",
        "count":15,
        "total":1,
        "data": ret
    }
    return HttpResponse(json.dumps(data))

# 返回主机页面数据,或执行删除操作等
def host(request):
    return render(request,"host.html")